// API ตารางงาน: Cloudflare Pages Functions + D1
// ต้องตั้งค่า: D1 binding ชื่อ DB, secret ชื่อ APP_PASSWORD และ SESSION_SECRET

const enc = new TextEncoder();
const SESSION_DAYS = 30;
const MAX_EVENTS = 3000;
const ID_RE = /^[A-Za-z0-9_-]{1,64}$/;
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

class HttpErr extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const json = (body, status = 200, extra = {}) => new Response(JSON.stringify(body), {
  status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...extra }
});
const fail = (status, error) => json({ error }, status);

// ---------- เข้ารหัส / session ----------
const b64u = u8 => btoa(String.fromCharCode(...u8)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
async function mac(secret, msg) {
  const key = await crypto.subtle.importKey('raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return new Uint8Array(await crypto.subtle.sign('HMAC', key, enc.encode(msg)));
}
const same = (a, b) => { if (a.length !== b.length) return false; let d = 0; for (let i = 0; i < a.length; i++) d |= a[i] ^ b[i]; return d === 0; };
const passOk = async (env, given) =>
  same(await mac(env.SESSION_SECRET, 'pw:' + given), await mac(env.SESSION_SECRET, 'pw:' + env.APP_PASSWORD));
// token = วันหมดอายุ.ลายเซ็น (ลายเซ็นผูกกับรหัสผ่านปัจจุบัน: เปลี่ยนรหัส = ทุกเครื่องต้องล็อกอินใหม่)
const sign = (env, exp) => mac(env.SESSION_SECRET, 'sess:' + exp + ':' + env.APP_PASSWORD);
async function makeToken(env) { const exp = Date.now() + SESSION_DAYS * 864e5; return exp + '.' + b64u(await sign(env, exp)); }
async function tokenOk(env, tok) {
  const m = /^(\d{10,16})\.([A-Za-z0-9_-]+)$/.exec(tok || '');
  if (!m || +m[1] < Date.now()) return false;
  return same(enc.encode(b64u(await sign(env, m[1]))), enc.encode(m[2]));
}
const getCookie = (req, name) => {
  for (const p of (req.headers.get('cookie') || '').split(';')) {
    const i = p.indexOf('=');
    if (i > 0 && p.slice(0, i).trim() === name) return p.slice(i + 1).trim();
  }
  return '';
};
const cookie = (v, maxAge) => `sid=${v}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${maxAge}`;

// ---------- ตรวจข้อมูลที่รับเข้ามา ----------
async function readBody(req) {
  const t = await req.text();
  if (t.length > 4_000_000) throw new HttpErr(413, 'too_large');
  try { return JSON.parse(t); } catch { throw new HttpErr(400, 'bad_json'); }
}
const str = (v, max) => String(v ?? '').slice(0, max);
function cleanEv(o, id) {
  if (!o || typeof o !== 'object') return null;
  const name = str(o.name, 300).trim(), date = str(o.date, 10);
  if (!name || !DATE_RE.test(date)) return null;
  let type = Number.parseInt(o.type, 10);
  if (!Number.isInteger(type) || type < 0 || type > 50) type = 0;
  return { id, name, date, time: str(o.time, 100), place: str(o.place, 300), detail: str(o.detail, 5000),
           menu: str(o.menu, 5000), guests: str(o.guests, 20), leader: str(o.leader, 5000), type };
}
function cleanCats(list) {
  if (!Array.isArray(list) || !list.length || list.length > 30) return null;
  const out = list.map(c => str(c, 100).trim());
  return out.every(Boolean) ? out : null;
}

// ---------- SQL ----------
const bump = db => db.prepare("INSERT INTO meta(key,value) VALUES('rev','1') ON CONFLICT(key) DO UPDATE SET value=CAST(value AS INTEGER)+1");
const catsStmt = (db, cats) => db.prepare("INSERT INTO meta(key,value) VALUES('cats',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").bind(JSON.stringify(cats));
async function getRev(db) {
  const r = await db.prepare("SELECT value FROM meta WHERE key='rev'").first();
  return r ? parseInt(r.value, 10) || 0 : 0;
}
const UPSERT = `INSERT INTO events(id,name,date,time,place,detail,menu,guests,leader,type,updated_at)
 VALUES(?,?,?,?,?,?,?,?,?,?,?)
 ON CONFLICT(id) DO UPDATE SET name=excluded.name,date=excluded.date,time=excluded.time,place=excluded.place,
 detail=excluded.detail,menu=excluded.menu,guests=excluded.guests,leader=excluded.leader,type=excluded.type,updated_at=excluded.updated_at`;
const BULK = `INSERT INTO events(id,name,date,time,place,detail,menu,guests,leader,type,updated_at)
 SELECT json_extract(value,'$.id'),json_extract(value,'$.name'),json_extract(value,'$.date'),json_extract(value,'$.time'),
 json_extract(value,'$.place'),json_extract(value,'$.detail'),json_extract(value,'$.menu'),json_extract(value,'$.guests'),
 json_extract(value,'$.leader'),json_extract(value,'$.type'),? FROM json_each(?)`;

// ---------- เส้นทาง ----------
async function login(req, env) {
  const db = env.DB, ip = req.headers.get('CF-Connecting-IP') || 'x', now = Date.now();
  const { n } = await db.prepare('SELECT COUNT(*) AS n FROM login_fail WHERE ip=? AND at>?').bind(ip, now - 10 * 60 * 1000).first();
  if (n >= 5) return fail(429, 'too_many_attempts');
  const b = await readBody(req);
  if (typeof b.password !== 'string' || !(await passOk(env, b.password))) {
    await db.batch([
      db.prepare('INSERT INTO login_fail(ip,at) VALUES(?,?)').bind(ip, now),
      db.prepare('DELETE FROM login_fail WHERE at<?').bind(now - 3600 * 1000)
    ]);
    return fail(401, 'bad_password');
  }
  await db.prepare('DELETE FROM login_fail WHERE ip=?').bind(ip).run();
  return json({ ok: true }, 200, { 'set-cookie': cookie(await makeToken(env), SESSION_DAYS * 86400) });
}

async function route(req, env) {
  if (!env.DB || !env.APP_PASSWORD || !env.SESSION_SECRET) return fail(503, 'not_configured');
  const url = new URL(req.url), method = req.method, db = env.DB;
  let seg;
  try { seg = url.pathname.replace(/^\/api\/?/, '').split('/').filter(Boolean).map(decodeURIComponent); }
  catch { return fail(400, 'bad_path'); }
  if (method !== 'GET' && method !== 'HEAD') {
    const o = req.headers.get('origin');
    if (o && o !== url.origin) return fail(403, 'bad_origin');
  }
  const [a, b] = seg;
  if (a === 'login' && method === 'POST') return login(req, env);
  if (a === 'logout' && method === 'POST') return json({ ok: true }, 200, { 'set-cookie': cookie('', 0) });
  if (!(await tokenOk(env, getCookie(req, 'sid')))) return fail(401, 'unauthorized');

  if (a === 'me' && method === 'GET') return json({ ok: true });

  if (a === 'data' && method === 'GET') {
    const rev = await getRev(db), since = url.searchParams.get('rev');
    if (since !== null && since === String(rev)) return json({ same: true, rev });
    const ev = (await db.prepare('SELECT id,name,date,time,place,detail,menu,guests,leader,type FROM events ORDER BY date,id').all()).results;
    const row = await db.prepare("SELECT value FROM meta WHERE key='cats'").first();
    let cats = null; try { cats = row ? JSON.parse(row.value) : null; } catch { /* ignore */ }
    return json({ rev, ev, cats });
  }

  if (a === 'events' && b && method === 'PUT') {
    if (!ID_RE.test(b)) return fail(400, 'bad_id');
    const e = cleanEv(await readBody(req), b);
    if (!e) return fail(400, 'bad_event');
    await db.batch([
      db.prepare(UPSERT).bind(e.id, e.name, e.date, e.time, e.place, e.detail, e.menu, e.guests, e.leader, e.type, Date.now()),
      bump(db)
    ]);
    return json({ ok: true });
  }

  if (a === 'events' && b && method === 'DELETE') {
    if (!ID_RE.test(b)) return fail(400, 'bad_id');
    await db.batch([db.prepare('DELETE FROM events WHERE id=?').bind(b), bump(db)]);
    return json({ ok: true });
  }

  if (a === 'cats' && method === 'PUT') {
    const cats = cleanCats((await readBody(req)).list);
    if (!cats) return fail(400, 'bad_cats');
    await db.batch([catsStmt(db, cats), bump(db)]);
    return json({ ok: true });
  }

  if (a === 'replace' && method === 'POST') {          // กู้คืน/นำเข้า: แทนที่ข้อมูลทั้งหมดในครั้งเดียว
    const body = await readBody(req), cats = cleanCats(body.cats);
    if (!cats || !Array.isArray(body.ev) || body.ev.length > MAX_EVENTS) return fail(400, 'bad_payload');
    const seen = new Set(), rows = [], now = Date.now();
    for (const raw of body.ev) {
      let id = raw && ID_RE.test(String(raw.id)) && !seen.has(String(raw.id)) ? String(raw.id) : crypto.randomUUID().replace(/-/g, '').slice(0, 20);
      const e = cleanEv(raw, id);
      if (!e) continue;
      if (e.type >= cats.length) e.type = 0;
      seen.add(id); rows.push(e);
    }
    const st = [db.prepare('DELETE FROM events')];
    for (let i = 0; i < rows.length; i += 100) st.push(db.prepare(BULK).bind(now, JSON.stringify(rows.slice(i, i + 100))));
    st.push(catsStmt(db, cats), bump(db));
    await db.batch(st);
    return json({ ok: true, count: rows.length });
  }
  return fail(404, 'not_found');
}

export async function onRequest({ request, env }) {
  try { return await route(request, env); }
  catch (e) {
    if (e instanceof HttpErr) return fail(e.status, e.message);
    console.error(e);
    return fail(500, 'server_error');
  }
}
